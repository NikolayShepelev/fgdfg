﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberRecording.NetWorkModel
{
    internal class Neurons
    {
        private double[] weights;
        private double[] inputs;
        private double output;
        private double derativate;
        public double[] Weights { get => weights; set => weights = value; }
        public double[] Inputs { get => inputs; set => inputs = value; }
        public double Output { get => output; }
        public double Derativate { get => derativate; }
        private Neurons(double[] weights, TypeNeuron type)
        {
            
        }
        private double HyperbTang
        {
            
        }
    }
}
