﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NumberRecording.NetWorkModel;

namespace NumberRecording
{
    public partial class Form1 : Form
    {
        //ПОЛЯ
        private int[] inputData = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; //massiv knopok
        private string pathMyApp; //файл где екзешник
        public Form1()
        {
            InitializeComponent();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChngStatButton(button1, 0);
        }
        private void button2_Click(object sender, EventArgs e)
        {
            ChngStatButton(button2, 1);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            ChngStatButton(button3, 2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            ChngStatButton(button4, 3);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            ChngStatButton(button5, 4);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            ChngStatButton(button6, 5);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            ChngStatButton(button7, 6);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ChngStatButton(button8, 7);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ChngStatButton(button9, 8);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ChngStatButton(button10, 9);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            ChngStatButton(button11, 10);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            ChngStatButton(button12, 11);
        }

        private void button13_Click(object sender, EventArgs e)
        {
            ChngStatButton(button13, 12);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            ChngStatButton(button14, 13);
        }

        private void button15_Click(object sender, EventArgs e)
        {
            ChngStatButton(button15, 14);
        }
        private void ChngStatButton(Button b,int index)
        {
            if(b.BackColor == Color.Transparent)
            {
                b.BackColor = Color.Red;
                inputData[index] = 1;
            }
            else
            {
                b.BackColor= Color.Transparent;
                inputData[index] = 0;
            }
            label1.Text= inputData[index].ToString();
        }

        private void ButtonSaveTrainSample_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Сохранение обучающего примера", "SaveTrain", MessageBoxButtons.OK, MessageBoxIcon.Information);
            string tmpString = numericUpDown1.Value.ToString();

            pathMyApp = AppDomain.CurrentDomain.BaseDirectory + "TrainSampls.txt";
            for (int i = 0; i < inputData.Length; i++)
            {
                tmpString = tmpString + " " + inputData[i].ToString();
            }
            tmpString+= "\n";
            File.AppendAllText(pathMyApp, tmpString);
            string[] aaaaaaaaaa=File.ReadAllLines(pathMyApp);

        }

        private void ButtonSaveExampTrain_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Сохранение тестового примера", "SaveTrain", MessageBoxButtons.OK, MessageBoxIcon.Information);
            string tmpString2 = numericUpDown1.Value.ToString();

            pathMyApp = AppDomain.CurrentDomain.BaseDirectory + "TestSampls.txt";
            for (int i = 0; i < inputData.Length; i++)
            {
                tmpString2 = tmpString2 + " " + inputData[i].ToString();
            }
            tmpString2 += "\n";
            File.AppendAllText(pathMyApp, tmpString2);
            string[] aaaaaaaaab = File.ReadAllLines(pathMyApp);
        }
    }
}
