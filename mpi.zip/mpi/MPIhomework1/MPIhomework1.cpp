﻿#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <ctime>
#include <mpi.h>
#define N 10
using namespace std;
int proc_count, proc_this;
int main(int argc, char** argv)
{
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &proc_count);
	MPI_Comm_rank(MPI_COMM_WORLD, &proc_this);

	/*const int N = 10;
	double a[N] = { 1,2,3,4,5,6,7,8,9,10 };*/
	double* a;
	a = new double[N];
	for (int i = 0; i < N; i++) 
		a[i] =rand ()%10;
	double sum = 0;
	int k = (N - 1) / proc_count + 1;
	int ibeg = proc_this * k;
	int iend = (proc_this + 1) * k - 1;
	if (ibeg >= N)
		iend = ibeg - 1;
	else
		if (iend >= N)
			iend = N - 1;
	for (int i = ibeg; i <= iend; i++)
	{
		sum += a[i];
	}
	printf("Block sum by process number %d = %f, starting position = %d, last position = %d\n", proc_this, sum, ibeg, iend);
	MPI_Finalize();
	return 0;
}